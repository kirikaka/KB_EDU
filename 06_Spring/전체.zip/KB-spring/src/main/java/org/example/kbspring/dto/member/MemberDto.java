package org.example.kbspring.dto.member;


import lombok.Data;

@Data
public class MemberDto {
    private String email;
    private String name;
}
