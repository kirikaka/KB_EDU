<template>
  <div>
    <h1>LOGIN PAGE</h1>
    아이디 : <input type="text" v-model.trim="userId" /><br />
    비밀번호 : <input type="password" v-model.trim="userPassword" />
    <br />
    <button @click="login">로그인</button> / <button>로그아웃</button>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import axios from 'axios';

const userId = ref('');
const userPassword = ref('');

const BASE_URL = '/api';

async function login() {
  try {
    const loginUrl = BASE_URL + '/users';
    const loginRes = await axios.get(loginUrl);

    console.log('로그인 통신결과 : ', loginRes);
  } catch (e) {
    alert('로그인 통신 에러 발생');
    console.error(e);
  }
}
</script>
