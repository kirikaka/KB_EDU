<script setup></script>

<template>
  <div>
    <h1>Welcome to the Vue Router World</h1>
  </div>
</template>
