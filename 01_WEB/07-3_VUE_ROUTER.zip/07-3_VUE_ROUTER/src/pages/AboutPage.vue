<template>
  <div>
    <h1>Describe Router in a Picture</h1>
  </div>
</template>

<style></style>
