<script setup></script>

<template>
  <div>
    <h1>Here is the 404 page</h1>
    <p>We tried our best but there is not such route in our service</p>
  </div>
</template>
