import { createApp } from 'vue';
import App from './App.vue';

app.use(router);

createApp(App).mount('#app');
