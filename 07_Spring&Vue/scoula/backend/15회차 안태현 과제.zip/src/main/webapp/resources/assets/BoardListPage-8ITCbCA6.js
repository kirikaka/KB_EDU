import{_ as e,c,o}from"./index-BnyFdYfi.js";const r={};function t(n,a){return o(),c("h1",null,"게시판 목록")}const _=e(r,[["render",t]]);export{_ as default};
