import{_ as e,c,o as n}from"./index-BnyFdYfi.js";const o={};function r(t,a){return n(),c("h1",null,"회원가입")}const _=e(o,[["render",r]]);export{_ as default};
