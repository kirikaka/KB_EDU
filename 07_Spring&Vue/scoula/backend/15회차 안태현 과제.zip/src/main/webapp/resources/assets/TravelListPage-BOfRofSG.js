import{_ as e,b as c,o as r}from"./index-FzgDuLKk.js";const t={};function n(o,a){return r(),c("h1",null,"여행 페이지")}const _=e(t,[["render",n]]);export{_ as default};
