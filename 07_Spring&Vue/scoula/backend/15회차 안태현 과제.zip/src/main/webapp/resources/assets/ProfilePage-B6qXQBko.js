import{_ as e,c,o}from"./index-BnyFdYfi.js";const r={};function n(t,a){return o(),c("h1",null,"회원정보")}const _=e(r,[["render",n]]);export{_ as default};
