package ex0423.module;


public record Member(String id, String name, int age) {

}
