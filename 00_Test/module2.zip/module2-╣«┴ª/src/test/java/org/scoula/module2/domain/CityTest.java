package org.scoula.module2.domain;

import static org.junit.jupiter.api.Assertions.*;

class CityTest {
  public void test() {
    City city = City.builder()
        .build();
  }
}